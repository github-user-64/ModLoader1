﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace cs1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //AppDomainSetup ads = new AppDomainSetup();
            //ads.ApplicationName = "Shadow";

            ////应用程序根目录
            //ads.ApplicationBase = AppDomain.CurrentDomain.BaseDirectory;

            ////子目录（相对形式）在AppDomainSetup中加入外部程序集的所在目录，多个目录用分号间隔
            ////ads.PrivateBinPath = assemblyPlugs;
            ////设置缓存目录
            //ads.CachePath = ads.ApplicationBase;                //获取或设置指示影像复制是打开还是关闭
            //ads.ShadowCopyFiles = "true";                //获取或设置目录的名称，这些目录包含要影像复制的程序集
            //ads.ShadowCopyDirectories = ads.ApplicationBase;

            //ads.DisallowBindingRedirects = false;
            //ads.DisallowCodeDownload = true;

            //ads.ConfigurationFile = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;

            ////Create evidence for the new application domain from evidence of
            //Evidence adevidence = AppDomain.CurrentDomain.Evidence;


            AppDomain newDomain = AppDomain.CreateDomain("NewDomain_cs2");
            //AppDomain newDomain = AppDomain.CreateDomain("NewDomain_cs2", adevidence, ads);

            string s1 = Assembly.GetExecutingAssembly().GetName().FullName;//程序集名称, cs1
            string s2 = typeof(a1).FullName;//类完整名称, cs1.a1
            a1 instance = (a1)newDomain.CreateInstanceAndUnwrap(s1, s2);

            IObject iobj = null;

            iobj = instance.a(() =>
            {
                Assembly assembly = Assembly.Load(File.ReadAllBytes("F:\\F_MY1\\File\\RJWJ\\C#\\cs1\\cs2\\bin\\Debug\\cs2.dll"));

                Type cstype = assembly.GetType("cs2.PlugPut");
                object o = Activator.CreateInstance(cstype);

                return o as IObject;
            });

            string ss = iobj.a1(114514);

            Assembly[] a = AppDomain.CurrentDomain.GetAssemblies();//在调用了cs2的asd方法后, cs2的程序集并没有被加载到当前的应用程序域中

            //!
            Console.WriteLine("ok");
            Console.ReadLine();
            //!
        }
    }
}
