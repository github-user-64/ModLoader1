﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cs1;

namespace cs2
{
    //[Serializable]
    public class PlugPut : MarshalByRefObject, IObject
    {
        public string a1(int i)
        {
            Console.WriteLine("cs2_iobj" + i);
            return "cs2_return";
        }
    }
}