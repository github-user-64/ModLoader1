﻿using System;

namespace cs1
{
    public class a1 : MarshalByRefObject
    {
        public IObject a(Func<IObject> a)
        {
            return a?.Invoke();
        }
    }
}
