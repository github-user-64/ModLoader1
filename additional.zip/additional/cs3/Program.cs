﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Kernel.Interface;
using Kernel.ServiceAgent;

namespace cs3
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            using (ServiceManager<IObjcet> manager = new ServiceManager<IObjcet>())
            {
                string result = manager.Proxy.Put("apprun one");
                Console.WriteLine(result);
                Console.WriteLine("");
                Console.WriteLine("                         Thread AppDomain info                             ");
                Console.WriteLine(manager.CotrProxy.FriendlyName);
                Console.WriteLine(Thread.GetDomain().FriendlyName);
                Console.WriteLine(manager.CotrProxy.BaseDirectory);
                Console.WriteLine(manager.CotrProxy.ShadowCopyFiles);
                Console.WriteLine("");
            }

            Console.WriteLine("cs3");
            Console.ReadLine();
        }
    }
}
